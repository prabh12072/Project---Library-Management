Instructions to run the application 


This is Web based application hosted at localhost:9999.

Start the tomcat server at port 9999 and launch the application.It will be redirected to following URL localhost:9999/Q4servlet.

To go further into application it is password protected with username - Prabhjot and Password - Prabhjot.

As soon as username and password is authenticated application will be redirected to Library where some basic guidelines and New arrivals can be seen

To issue book click on the issue/returrn tab(Top left) it will be redirected to form where it will ask for the details of book to be issues,date of issuing the book,
No. of book issued and roll no/Emp No.These details are mandatory in order to issue the book.Press the submit button.Book will be issued and it can be seen in right 
portion of screen.


Challenges faced:

1. To much effort on UI since application consist of small small elements which has to be handled carefully so that user can use application easily.
2. Storing data in local storage is little bit confusing which took around 3-4 hours to figure out.
3. Fetching and storing data in json was one major point where I spend one full day because of syntax errors and runtime errors.
4. compatibility issues with eclipse and tomcat version 7.Basically when I made changes in the jsp and html tomcat still loads older jsp and html due to some caching
and browser issues.It took lot of research work to figure out how to load changes in tomcat.
5. Last but not the least-  Many tags are supported by chrome/firefox.Some are working in firefox not in chrome and vice a versa.I took lot of time to make application
browser compatible in commonly used browsers.



Further Improvement :

I understand to much improvement is required in the application.I am not able to provide return book functionality(Time constraints).UI can be further improved.
This application can be treated as basic version with few functioning.I hope gradually I will try to improve further with more output in less hours.




		