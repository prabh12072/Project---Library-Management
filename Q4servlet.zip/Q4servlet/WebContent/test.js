
$(document).ready(function(){
        
        // first check the movies already booked
        checkBooksBooked();
        
     
        
        // on form submit
        $("#book_book").submit(function(event){
            
            // prevent on submit page refresh
            event.preventDefault();
            
            // check locally stored data
            if(window.localStorage){
                var booksListJson = localStorage.getItem('books_list');
                var books_list = booksListJson ? JSON.parse(booksListJson) : [];
                var books = $("#book_name").val();
                books_list.push(books);
                $("#book_name option[value='" + books + "']").hide();
               
                localStorage.setItem('books_list', JSON.stringify(books_list));
               
            }
           
            
            // clear the form					
            $( '#book_book' ).each(function(){
                this.reset();
            });
    
     
           
            checkBooksBooked();
        });
        
        // set minimum date in datepicker as today
        var today = new Date().toISOString().split('T')[0];
        document.getElementsByName("date")[0].setAttribute('min', today);
        
    });
    
    

    
    // fetch details of movies booked
    function checkBooksBooked(){
        $("#books_list").html("<span id='none'>(none)</span>");
        if(window.localStorage){
            if(localStorage.getItem('books_list')){
                $("#none").remove();
                var movieListJson = localStorage.getItem('books_list');
                var books_list = JSON.parse(movieListJson);
                    
                var sr_no = 0;
                $.each(books_list,function(key,value){
                	$("#book_name option[value='" + value + "']").hide();
                    $("#books_list").append(++sr_no + ". " + value + "<br>");
                    
                });
                
            }
        }
    }